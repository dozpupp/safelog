import './assets/index.js-DlmN2MwZ.js';
